/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaant;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hermes
 */
public class Arquivo {
    
    private FileWriter arqW;
    private BufferedWriter escritor;
    
    private FileWriter arqR;
    private BufferedWriter leitor;
    
    private List<Livro> listaLivros;
    
    public String nomeArquivo;
    
    public Arquivo(String nomeArquivo){
        
        this.nomeArquivo = nomeArquivo;
        
        listaLivros = new ArrayList<>();
        
        {
            
           }
    }
    
}

