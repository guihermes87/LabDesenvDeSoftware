/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaant;

/**
 *
 * @author laboratorio
 */
public class Livro {
    
   public String titulo;
    public String autor;
    public String anopublicacao;
    public String tipo;
    public String categoria;
    public String situacao;

    public Livro(String titulo, String autor, String anopublicacao, String tipo, String categoria, String situacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anopublicacao = anopublicacao;
        this.tipo = tipo;
        this.categoria = categoria;
        this.situacao = situacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(String anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    @Override
    public String toString() {
        return "Livro{" + "titulo=" + titulo + ", autor=" + autor + ", anopublicacao=" + anopublicacao + ", tipo=" + tipo + ", categoria=" + categoria + ", situacao=" + situacao + '}';
    }
    
    
     public Object[] obterDados(){
    
    return new Object[] {titulo, tipo, autor, anopublicacao, categoria, situacao};
    
    }
    
}
